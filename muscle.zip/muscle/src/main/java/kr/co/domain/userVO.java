package kr.co.domain;

import lombok.Data;

@Data
public class userVO {
   private String id;
   private String pw;
   private String name;
   private String tel;
   private int idx_b;
   private String title;
   private String content;
}